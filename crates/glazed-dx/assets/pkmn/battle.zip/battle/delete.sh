while IFS= read -r line; do 
	rm front/normal/$line
	rm front/shiny/$line
	rm back/normal/$line
	rm back/shiny/$line
done < "exclude.txt"